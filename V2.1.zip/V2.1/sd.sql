SET LINESIZE 5000 pagesize 0 Arraysize 51 TAB OFF
select * from table(jss.gtop(51))
/
